import bcrypt

my_password = b'hemligt'
my_salt = bcrypt.gensalt(rounds=12)

hashed_pw = bcrypt.hashpw(my_password, my_salt)
print('hash:', hashed_pw)
print('salt: ', my_salt)




